let fileInput = null;

document.addEventListener("DOMContentLoaded", function () {
    fileInput = byId("file");
    applySettingsSelections();
    bindSettingsPageEvents();
    refreshBatteryCalibrationReference();
    setTimeout(showPage, 10);
});

function bindSettingsPageEvents() {
    var toggleButtons = document.querySelectorAll(".section-toggle");
    for (var i = 0; i < toggleButtons.length; i += 1) {
        toggleButtons[i].addEventListener("click", function (event) {
            var button = event.currentTarget;
            ToggleSection(button, button.dataset.target);
        });
    }

    var toggleAllButton = byId("btAllSettingsPage");
    if (toggleAllButton) {
        toggleAllButton.addEventListener("click", ToggleAllSections);
    }

    var jumpButtons = document.querySelectorAll(".settings-jump");
    for (var j = 0; j < jumpButtons.length; j += 1) {
        jumpButtons[j].addEventListener("click", function (event) {
            var target = event.currentTarget.dataset.target;
            if (target) {
                openSettingsSection(target);
            }
        });
    }

    var backButton = byId("backToOverviewButton");
    if (backButton) {
        backButton.addEventListener("click", function () {
            window.location.assign("/index.html");
        });
    }

    var logoutButtonElement = byId("logoutBtn");
    if (logoutButtonElement) {
        logoutButtonElement.addEventListener("click", logoutButton);
    }

    var downloadButton = byId("downloadConfigButton");
    if (downloadButton) {
        downloadButton.addEventListener("click", downloadConfigAsJson);
    }

    var restoreButton = byId("restoreConfigBackupButton");
    if (restoreButton) {
        restoreButton.addEventListener("click", restoreConfigBackup);
    }

    var batteryReadButton = byId("batteryCalibrationReadButton");
    if (batteryReadButton) {
        batteryReadButton.addEventListener("click", refreshBatteryCalibrationReference);
    }

    var batteryApplyButton = byId("batteryCalibrationApplyButton");
    if (batteryApplyButton) {
        batteryApplyButton.addEventListener("click", applyBatteryCalibration);
    }

    if (fileInput) {
        fileInput.addEventListener("change", uploadConfig);
    }

    var settingsForm = byId("form1");
    if (settingsForm) {
        settingsForm.addEventListener("submit", saveSettings);
        bindSensorNameValidation(settingsForm);
    }

    bindWifiPrioritySwap(settingsForm);
}

function bindSensorNameValidation(form) {
    var fields = form.querySelectorAll(".sensor-name-input");
    for (var i = 0; i < fields.length; i += 1) {
        fields[i].addEventListener("input", validateSensorNameField);
        fields[i].addEventListener("blur", function (event) {
            event.currentTarget.value = event.currentTarget.value.trim();
            validateSensorNameField(event);
        });
    }
}

function validateSensorNameField(event) {
    var field = event.currentTarget;
    var value = field.value.trim();
    var valid = value.length > 0 && value.length <= 17 && /^[\x20-\x7e]+$/.test(value);
    field.setCustomValidity(valid ? "" : "Enter 1 to 17 printable characters without umlauts.");
}

function applySettingsSelections() {
    var selections = window.settingsSelections || {};
    var form = document.forms.SetForm;
    if (!form) return;

    Object.keys(selections).forEach(function (fieldName) {
        var field = form[fieldName];
        if (!field) return;

        if (field.tagName === 'SELECT') {
            field.selectedIndex = selections[fieldName];
        } else {
            field.value = selections[fieldName];
        }
    });

    if (selections.crypt == 1) {
        byId("logoutBtn").style.display = "block";
    }
}

function bindWifiPrioritySwap(form) {
    if (!form) return;

    var fields = [form.corder1, form.corder2, form.corder3].filter(function (field) {
        return !!field;
    });

    fields.forEach(function (field) {
        field.dataset.previousValue = field.value;
        field.addEventListener("change", function (event) {
            var changedField = event.currentTarget;
            var previousValue = changedField.dataset.previousValue || "0";
            var newValue = changedField.value;

            if (newValue !== "0") {
                fields.forEach(function (otherField) {
                    if (otherField === changedField || otherField.value !== newValue) {
                        return;
                    }

                    otherField.value = previousValue;
                    otherField.dataset.previousValue = previousValue;
                });
            }

            changedField.dataset.previousValue = newValue;
        });
    });
}

function showPage() {
    byId("loader").style.display = "none";
    byId("myDiv").style.display = "block";
}

function setCalibrationFeedback(message, type) {
    var feedback = byId("batteryCalibrationFeedback");
    if (!feedback) return;

    feedback.textContent = message || "";
    feedback.classList.remove("is-error", "is-success");
    if (type === "error") {
        feedback.classList.add("is-error");
    } else if (type === "success") {
        feedback.classList.add("is-success");
    }
}

function trimCalibrationNumber(value, digits) {
    var number = Number(value);
    if (!isFinite(number)) {
        return "";
    }

    var fixed = number.toFixed(typeof digits === "number" ? digits : 6);
    fixed = fixed.replace(/\.?0+$/, "");
    return fixed === "-0" ? "0" : fixed;
}

async function refreshBatteryCalibrationReference() {
    var currentField = byId("batteryCalibrationCurrentVoltage");
    var rawField = byId("batteryCalibrationRawAdc");
    if (!currentField || !rawField) {
        return;
    }

    try {
        var response = await requestJson("/getdata?data=Battery&ts=" + Date.now());
        var voltageValue = response && response.BatteryVoltage !== undefined && response.BatteryVoltage !== null
            ? response.BatteryVoltage
            : "";
        var rawValue = response && response.BatteryAdc !== undefined && response.BatteryAdc !== null
            ? response.BatteryAdc
            : "";
        var calibrationAvailable = !response || response.CalibrationAvailable !== false;
        var calibrationMessage = response && response.CalibrationMessage ? response.CalibrationMessage : "";

        currentField.value = voltageValue !== "" ? voltageValue + " V" : "-";
        rawField.value = rawValue !== "" ? rawValue : "-";

        if (voltageValue !== "" && rawValue !== "" && calibrationAvailable) {
            setCalibrationFeedback(calibrationMessage || "Live values loaded. Now enter the multimeter value and apply the correction.", "");
        } else {
            setCalibrationFeedback(calibrationMessage || "The device did not return usable battery calibration values.", "error");
        }
    } catch (error) {
        setCalibrationFeedback("Live battery values could not be read from the device.", "error");
    }
}

function applyBatteryCalibration() {
    var form = document.forms.SetForm;
    if (!form) return;

    if (form.envSensor && form.envSensor.value === "VEdirect-Read") {
        setCalibrationFeedback("Battery calibration is disabled while VEdirect-Read is active.", "error");
        return;
    }

    var measuredField = byId("batteryCalibrationMeasuredVoltage");
    var rawField = byId("batteryCalibrationRawAdc");
    var currentField = byId("batteryCalibrationCurrentVoltage");
    var measuredVoltage = measuredField ? parseFloat(String(measuredField.value).replace(",", ".")) : NaN;
    var rawAdc = rawField ? parseFloat(rawField.value) : NaN;
    var currentVoltage = currentField
        ? parseFloat(String(currentField.value).replace("V", "").replace(",", "."))
        : NaN;

    if (!isFinite(measuredVoltage) || measuredVoltage <= 0) {
        setCalibrationFeedback("Please enter a valid measured battery voltage in volts.", "error");
        return;
    }

    if (!isFinite(rawAdc) || rawAdc <= 0) {
        setCalibrationFeedback("Please read live values first so the current ADC raw value is available.", "error");
        return;
    }

    var newSlope = measuredVoltage / rawAdc;
    if (!isFinite(newSlope) || newSlope <= 0) {
        setCalibrationFeedback("The measured voltage and ADC value did not produce a valid calibration.", "error");
        return;
    }

    form.a2vslope.value = "0";
    form.a1vslope.value = trimCalibrationNumber(newSlope, 8);
    form.voffset.value = "0";

    var deviationInfo = "";
    if (isFinite(currentVoltage) && currentVoltage > 0) {
        deviationInfo = " Previous live reading was " + trimCalibrationNumber(currentVoltage, 3) + " V.";
    }

    setCalibrationFeedback(
        "Calibration applied. The helper rebuilt the battery curve as a simple linear mapping from the live ADC value. " +
        "A2 was reset to 0, A1 is now " + form.a1vslope.value + " and Offset is 0 V." +
        deviationInfo + " Save settings to keep it.",
        "success"
    );
}

function settingsCsrfToken(form) {
    if (typeof csrfToken === "function") {
        var token = csrfToken();
        if (token) {
            return token;
        }
    }

    var csrfField = form ? form.querySelector("input[name='csrf']") : null;
    return csrfField ? csrfField.value : "";
}

function normalizeHttpsEndpoint(value) {
    var normalized = String(value || "").trim();
    if (!normalized) {
        return "";
    }

    var queryIndex = normalized.indexOf("?");
    if (queryIndex >= 0) {
        normalized = normalized.slice(0, queryIndex);
    }

    while (normalized.endsWith("/")) {
        normalized = normalized.slice(0, -1);
    }

    return normalized;
}

function isValidHttpsEndpoint(value) {
    var normalized = normalizeHttpsEndpoint(value);
    if (!normalized || !normalized.startsWith("https://")) {
        return false;
    }

    return normalized.lastIndexOf("/") > 8;
}

async function saveSettings(event) {
    event.preventDefault();

    var form = event.currentTarget;
    var sensorNameFields = form ? form.querySelectorAll(".sensor-name-input") : [];
    for (var i = 0; i < sensorNameFields.length; i += 1) {
        sensorNameFields[i].value = sensorNameFields[i].value.trim();
        validateSensorNameField({ currentTarget: sensorNameFields[i] });
    }
    if (form && !form.reportValidity()) {
        return;
    }
    var otaField = form ? form.elements.mdsOtaUrl : null;
    if (otaField && otaField.value.trim().length > 0 && !isValidHttpsEndpoint(otaField.value)) {
        alert("The MDS OTA endpoint must be a valid https:// URL that points to the OTA script.");
        otaField.focus();
        return;
    }

    var token = settingsCsrfToken(form);
    var formData = new FormData(form);
    if (token) {
        formData.set("csrf", token);
    }
    var body = new URLSearchParams(formData);

    setBusyState("Saving settings...");

    try {
        var result = await request("/savesettings", {
            method: "POST",
            headers: token ? {
                "Content-Type": "application/x-www-form-urlencoded",
                "X-CSRF-Token": token
            } : {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: body.toString(),
            credentials: "same-origin",
            redirect: "follow",
            timeoutMs: 15000
        });

        if (!result.ok) {
            var message = "Settings could not be saved.";
            if (result.json && result.json.message) {
                message = result.json.message;
            }
            throw new Error(message);
        }

        window.location.assign("/settings.html");
    } catch (error) {
        clearBusyState();
        alert(error && error.message ? error.message : "Settings could not be saved.");
    }
}

function ToggleSection(ele, target) {
    var targetElement = byId(target);
    var isHidden = targetElement.style.display === "none" || targetElement.style.display === "";
    if (isHidden) {
        targetElement.style.display = "block";
        ele.value = '-';
    } else {
        targetElement.style.display = "none";
        ele.value = '+';
    }
}

function ToggleAllSections() {
    const nodes = document.getElementsByClassName("collapsible");
    const shouldOpen = !nodes.length || nodes[0].style.display == "none" || nodes[0].style.display === "";
    if (shouldOpen) {
        for (let i = 0; i < nodes.length; i++) {
            nodes[i].style.display = "block";
            byId("btAllSettingsPage").value = '-';
        }
    } else {
        for (let i = 0; i < nodes.length; i++) {
            nodes[i].style.display = "none";
            byId("btAllSettingsPage").value = '+';
            }
    }
    const nodes2 = document.getElementsByClassName("myToggleButton");
    if (!shouldOpen) {
        for (let i = 0; i < nodes2.length; i++) {
            nodes2[i].value = '+';
        }
    } else {
        for (let i = 0; i < nodes2.length; i++) {
            nodes2[i].value = '-';
        }
    }
}

function openSettingsSection(targetId) {
    var targetElement = byId(targetId);
    if (!targetElement) {
        return;
    }

    if (targetElement.style.display === "none" || targetElement.style.display === "") {
        targetElement.style.display = "block";
    }

    var button = document.querySelector('.section-toggle[data-target="' + targetId + '"]');
    if (button) {
        button.value = "-";
    }
}

function check_devaddr(iname) {
    var valuestring = "";
    if (iname == "devaddr") {
        valuestring = document.SetForm.devaddr.value;
    }
    var reguexp = /[^A-Z0-9]/;
    if (reguexp.exec(valuestring) || valuestring.length !== 8) {
        document.getElementById('sub').disabled = true;
        alert('Error!\\nUse only A-Z, 0-9, \\nAddress Length not 8');
    }
    else {
        document.getElementById('sub').disabled = false;
    }
}

function check_key(iname) {
    var valuestring = "";
    if (iname == "nskey") { valuestring = document.SetForm.nskey.value; }
    if (iname == "appkey") { valuestring = document.SetForm.appkey.value; }
    var reguexp = /[^a-fA-F0-9]/;
    if (valuestring.length > 0 && (reguexp.exec(valuestring) || valuestring.length !== 32)) {
        document.getElementById('sub').disabled = true;
        alert('Error!\\nUse only hex characters 0-9, A-F.\\nLeave empty to keep the existing key.');
    }
    else {
        document.getElementById('sub').disabled = false;
    }
}

function check_ssid(iname) {
    var valuestring = "";
    if (iname == "cssid1") { valuestring = document.SetForm.cssid1.value; }
    if (iname == "cssid2") { valuestring = document.SetForm.cssid2.value; }
    if (iname == "cssid3") { valuestring = document.SetForm.cssid3.value; }
    if (iname == "sssid") { valuestring = document.SetForm.sssid.value; }
    var reguexp = /[^\x20-\x7E]/;
    var isClientSsid = iname == "cssid1" || iname == "cssid2" || iname == "cssid3";
    if (reguexp.exec(valuestring) || (!isClientSsid && valuestring.length < 1) || valuestring.length > 30) {
        document.getElementById('sub').disabled = true;
        alert('Error!\nUse only printable characters.\nSSID length 1-30 for the hotspot, 0-30 for Wi-Fi clients.');
    }
    else {
        document.getElementById('sub').disabled = false;
    }
}

function check_tinterval(iname) {
    var valuestring = "";
    if (iname == "tinterval") { valuestring = document.SetForm.tinterval.value; }
    var reguexp = /[^0-9]/;
    if (reguexp.exec(valuestring) || valuestring < 1 || valuestring > 255) {
        document.getElementById('sub').disabled = true;
        alert('Error!\nUse only 0-9, \nValues 1...255');
    }
    else {
        document.getElementById('sub').disabled = false;
    }
}

function check_username(iname) {
    var valuestring = "";
    if (iname == "username") { valuestring = document.SetForm.username.value; }
    var reguexp = /[^A-z0-9\-]/;
    if (reguexp.exec(valuestring) || valuestring.length < 4 || valuestring.length > 20) {
        document.getElementById('sub').disabled = true;
        alert('Error!\nUse only a-z, A-Z, 0-9, -\nUsername Length 4-20');
    }
    else {
        document.getElementById('sub').disabled = false;
    }
}

function check_passwd(iname) {
    var valuestring = "";
    if (iname == "pagepasswd") { valuestring = document.SetForm.pagepasswd.value; }
    if (iname == "cpasswd1") { valuestring = document.SetForm.cpasswd1.value; }
    if (iname == "cpasswd2") { valuestring = document.SetForm.cpasswd2.value; }
    if (iname == "cpasswd3") { valuestring = document.SetForm.cpasswd3.value; }
    if (iname == "spasswd") { valuestring = document.SetForm.spasswd.value; }
    var reguexp = /[^\x20-\x7E]/;
    if (valuestring.length === 0) {
        document.getElementById('sub').disabled = false;
    }
    else if (reguexp.exec(valuestring) || valuestring.length < 8 || valuestring.length > 30) {
        document.getElementById('sub').disabled = true;
        alert('Error!\nUse only printable characters.\nPassword Length 8-30');
    }
    else {
        document.getElementById('sub').disabled = false;
    }
}

function check_mds_ota_url(iname) {
    var field = document.SetForm[iname];
    var value = field ? field.value.trim() : "";
    if (value.length > 0 && !isValidHttpsEndpoint(value)) {
        document.getElementById('sub').disabled = true;
        alert('Error!\nThe MDS OTA endpoint must be a valid https:// URL that points to the OTA script.');
    }
    else {
        document.getElementById('sub').disabled = false;
    }
}

function checkMainPowerMode(event) {
    var selectElement = event.target;
    var value = selectElement.value;
    if (value == "On") {
        requestJson("/getdata?data=mainPowerOn")
            .then(function (response) {
                if (response.mainPowerOn == "0" || response.mainPowerOn === 0) {
                    alert("Sleep/wakeup mode will be saved. The battery main switch is currently off (no 12 V at the Main Power Input), so the device may enter deep sleep shortly after saving.");
                }
            })
            .catch(function () {
                alert("Could not verify the Main Power Input state.");
            });
    }
}

function downloadConfigAsJson() {
    const formData = new FormData(form1);
    var myjsonString = JSON.stringify(Object.fromEntries(formData));
    var boardname = "boatmonitor-" + document.getElementById('deviceid').value;
    download(myjsonString, boardname + '.json', 'text/plain');
}

function uploadConfig() {
    // If there's no file, do nothing
    if (!fileInput || !fileInput.value.length) return;
    // Create a new FileReader() object
    let reader = new FileReader();
    // Setup the callback event to run when the file is read
    reader.onload = logFile;
    // Read the file
    reader.readAsText(fileInput.files[0]);
    //window.open('/savesettings', '_self');
}

/**
 * Handle submit events
 * @param  {Event} event The event object
 */
function handleSubmit (event) {
    // Stop the form from reloading the page
    event.preventDefault();
    // If there's no file, do nothing
    if (!fileInput || !fileInput.value.length) return;
    // Create a new FileReader() object
    let reader = new FileReader();
    // Setup the callback event to run when the file is read
    reader.onload = logFile;
    // Read the file
    reader.readAsText(fileInput.files[0]);
}

/**
 * Log the uploaded file to the console
 * @param {event} Event The file loaded event
 */
function logFile (event) {
    const form = document.getElementById("form1");
    if (!form) return;

    let json;
    try {
        json = JSON.parse(event.target.result);
    } catch (error) {
        alert("Config file could not be read. Please select a valid JSON backup.");
        return;
    }

    Object.entries(json).forEach(function (entry) {
        const key = entry[0];
        const value = entry[1];
        if (key === "csrf") return;

        const fields = document.getElementsByName(key);
        if (!fields.length) return;

        const field = fields[0];
        if (field.tagName === "SELECT") {
            field.value = value;
        } else if (field.type !== "hidden") {
            field.value = value;
        }
    });

    if (typeof form.requestSubmit === "function") {
        form.requestSubmit();
    } else {
        saveSettings({ preventDefault: function () {}, currentTarget: form });
    }
}

function download(content, fileName, contentType) {
    var a = document.createElement("a");
    var blob = new Blob([content], {type: contentType});
    a.href = URL.createObjectURL(blob);
    a.download = fileName;
    a.click();
}

function logoutButton() {
    request("/logout").finally(function () {
        setTimeout(function () {
            window.location.assign("/logged-out");
        }, 1000);
    });
}

function setBusyState(message) {
    document.getElementById("loader").style.display = "block";
    document.getElementById("myDiv").style.display = "none";
    if (message) {
        console.log(message);
    }
}

function clearBusyState() {
    byId("loader").style.display = "none";
    byId("myDiv").style.display = "block";
}

async function waitForDeviceAndRedirect(targetUrl, retries) {
    if (retries <= 0) {
        clearBusyState();
        alert("Device did not come back online in time. Please reload the page manually.");
        return;
    }

    try {
        await requestJson("/staticdata.json?ts=" + Date.now());
        window.location.replace(targetUrl);
        return;
    } catch (error) {
    }

    await delay(2000);
    waitForDeviceAndRedirect(targetUrl, retries - 1);
}

async function restoreConfigBackup() {
    if (!confirm("Restore the last automatic OTA config backup from LittleFS and reboot the device?")) {
        return;
    }

    setBusyState("Restoring config backup...");

    try {
        var response = await request("/restoreconfigbackup", { method: "POST" });
        if (!response.ok) {
            var serverMessage = response.json && response.json.message
                ? response.json.message
                : response.text;
            var statusMessage = response.status ? "HTTP " + response.status : "HTTP error";
            throw new Error(serverMessage || "Restore failed (" + statusMessage + ").");
        }

        setTimeout(function () {
            waitForDeviceAndRedirect("/settings.html", 45);
        }, 3000);
    } catch (error) {
        clearBusyState();
        alert(error && error.message ? error.message : "Restore failed.");
    }
}
